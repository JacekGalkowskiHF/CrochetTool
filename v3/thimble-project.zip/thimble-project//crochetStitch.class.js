function crochetStitch( ) {
	// TBD
}
