function crochetLink( context, type, fromNode, toNode ) {
	// *********************
	// SET STATICS and  CONSTANTS 
	// *********************
	
	// create dedicated link numbering sequence
	if ( typeof crochetLink.COUNTER == 'undefined' ) {
		crochetLink.COUNTER = new IdGenerator( 'LK' );
	};
	
	// define an array of recognized link types
	if ( typeof crochetLink.VALID_LINK_TYPES == 'undefined' ) {
		crochetLink.VALID_LINK_TYPES = [
			{
				code: "DEFAULT",
				length: 10
			},
			{
				code: "EXTERNAL",
				length: 10
			},
			{
				code: "ZERO",
				length: 0,
			},
		];
	};
	
	crochetLink.IS_VALID_TYPE_CODE = function( type ) {
		// given a string or an index, checks if it's a valid crochetLink type
		if ( 'string' == typeof( type ) ) {
			return ( crochetLink.VALID_LINK_TYPES.some( function ( e ) { return e.code == this }, type ) );
		} else {
			return false;
		}
	};
	
	crochetLink.DEF_LENGTH_BY_TYPE = function( type ) {
		// given a string, provided it's a valid  crochetNode type, returns the default length defined for that ink type 
		if ( !( crochetLink.IS_VALID_TYPE_CODE( type ) ) ) {
			console.error( 'crochetLink::IS_VALID_TYPE_CODE - invalid type code: "' + type + '"' );
      throw 'crochetLink 001';
		} else {
			return crochetLink.VALID_LINK_TYPES.find( function( e ) { return e.code == this; }, type ).length;
		};
	};
	
	argLen = arguments.length;
	
	//we need four arguments (context, link type, source node, target node)
	if ( 4 > argLen ) {
		console.error( 'crochetLink::crochetLink - not enough arguments to create a link' );
    throw 'crochetLink 002';
	};
	
	argContext = arguments[0]; // will be used later to register the new node in its parent crochetStitch or its parent crochetProject
	argType = arguments[1]; // will be used to set the link's type and also control the creation of other properties
	fromNode = arguments[2]; // to-be source node of the link
  toNode = arguments[3]; // to-be target node of the link
	
	// for each new crochetLink, the context must be set as either the containing crochetStitch or the containing crochetProject
	if ( !( argContext instanceof crochetProject ||  argContext instanceof crochetStitch) ) {
		console.error( 'crochetLink::crochetLink - cannot create a node without valid context. crochetStitch or crochetProject required!' ); 
    throw 'crochetLink 003';
	};
	
	// for each new link its type must be set as one valid types, either by using the type code or type number.
	if ( !( 'string' === typeof( argType )  || 'number' === typeof( argType ) ) ) {
		consloe.error( 'crochetLink::crochetLink - invalid link type. String or number required' );
    throw 'crochetLink 004';
	};
	if ( !( crochetLink.IS_VALID_TYPE_CODE( argType ) ) ) {
		console.error( 'crochetLink::crochetLink - invalid link type: "'+ argType + '"' );
    throw 'crochetLink 005';
	};
	
	//check form and to nodes are valid
	if ( !( fromNode instanceof crochetNode ) ) {
		console.error( 'crochetLink::crochetLink - cannot create a link from "' + fromNode.constructor.name + '"!');
    throw 'crochetLink 006';
	};
	if ( !( toNode instanceof crochetNode ) ) {
		console.error( 'crochetLink::crochetLink - cannot create a link to "' + toNode.constructor.name + '"!' );
    throw 'crochetLink 007';
	};
	
	// register the new link in its nodes' link lists
	fromNode.registerLink( this );
  toNode.registerLink( this );
	
	
	// *********************
	// PRIVATE PROPERTIES
	// *********************
	
	// basic
	this._source = fromNode;
	this._target = toNode;
	this._type = argType;
	
	// *********************
	// PUBLIC METHODS
	// *********************
	
  this.getSource = function() {
    return this._source;
  };
  
  this.getTarget = function() {
    return this._target;
  };
  
  /*
  this.getOtherEnd = function( node ) {
    if ( !( node instanceof crochetNode ) ) {
      throw 'crochetLink::getOtherEnd - cannot determine other end of the link if the first end is given as a "' + node.constructor.name + '"!';
    };
    if ( this._source === node) {
      return this._target;
    } else if ( this._target === node ) {
      return this._source;
    } else {
      return null;
    };
  };
  */
    
	this.getRealLen = function() {
		return this.target.getAsVector().getSumVector( this.source.getAsVector().scale( -1 ) ).getLen();
	};
	
	this.getDefLen = function() {
		return crochetLink.DEF_LENGTH_BY_TYPE( this._type );
	};
	
	//////////////////////////////////////////
	//   THIS IS WHERE I LAST FINISHED !!!  //
	//////////////////////////////////////////
	
	/* TO DO
	 - getAllNeighbors - returns all neighbors of source and target nodes
	 - getLen - depending on node type, get the desired length (could be either defLen OR, in case of chain spaces, sth. more complex)
	 - remove( null ) - housekeeping: deregister from both nodes and from context
	*/
	
}