function IdGenerator(pre) {
	
	this.index = 0;
	this.prefix = pre;
	this.next = function() {
		return pre + '_' + this.index++;
	};
	
};

////////////////////////////////////////////
// OVERRIDES FOR LACKING IE JAVASCRIPT DEFS
////////////////////////////////////////////

// in case Array.prototype.find is not defined
if (!Array.prototype.find) {
  console.log ('Array.find() was not defined - aplying override.')
  Object.defineProperty(Array.prototype, 'find', {
    value: function(predicate) {
      if (this === null) {
        throw new TypeError('Array.prototype.find called on null or undefined');
      }
      if (typeof predicate !== 'function') {
        throw new TypeError('predicate must be a function');
      }
      var list = Object(this);
      var length = list.length >>> 0;
      var thisArg = arguments[1];
      var value;

      for (var i = 0; i < length; i++) {
        value = list[i];
        if (predicate.call(thisArg, value, i, list)) {
          return value;
        }
      }
      return undefined;
    }
  });
}