function crochetNode() {

	// *********************
	// SET STATICS and  CONSTANTS 
	// *********************
	
	// create dedicated node numbering sequence
	if ( typeof crochetNode.COUNTER == 'undefined' ) {
		crochetNode.COUNTER = new IdGenerator( 'ND' );
	};
	
	// define an array of recognized node types and their parameters
	if ( typeof crochetNode.VALID_NODE_TYPES == 'undefined' ) {
		crochetNode.VALID_NODE_TYPES = [
			{
				code: "ORIGIN", // the first node in the crochetProject
			},
			{
				code: "START", // first node of a stitch. Also its first hook
			},
			{
				code: "FINISH", // last node of a stitch. Also its last loop
			},
			{
				code: "LOOP", // a node that other stitches' hooks can attach to 
			},
			{
				code: "HOOK", // a node that must attach to other stitches' loops
			},
			{
				code: "STRUCT", // a node that is only there for structure modeling
			},
			{
				code: "CH_SP_START", // first (not removable) loop of a "chain space" - the only node in a chain space to carry with itself information about its total length
			},
			{
				code: "CH_SP_CONT", // any subsequent node of a "chain space"
			},
		];
	};
	
	crochetNode.IS_VALID_TYPE_CODE = function( type ) {
		// given a string or an index, checks if it's a valid crochetNode type
		if ( 'string' == typeof( type ) ) {
			return ( crochetNode.VALID_NODE_TYPES.some( function( e ) { return e.code == this }, type ) );
		} else {
			return false;
		}
	};
	
	// *********************
	// VALIDATE CONSTRUCTOR ARGUMENTS
	// *********************
	
	// possible constructor calls are as follows:
	// crochetNode( context, nodeType ) - creates a node of specified type at the default position (0,0)
	// crochetNode( context, nodeType, x, y ) - creates a node of specified type at the position (x,y)	
	// crochetNode( context, nodeType, fromNode, prevLink, {linkType|linkLength} ) - creates a new node, that is placed in line with prevLink, in a distance from fromNode determined by the given linkType or linkLength
	// crochetNode( context, nodeType, nodeArray, referenceLink, {linkType1|linkLength1}, {linkType2|linkLength2} ) - creates a new node, that is placed in a distances determined by the given linkTypes or linkLengths from ends of referenceLink, and on the opposite side of that link, than the center of mass of all nodes in nodeArray is
	
	argLen = arguments.length;
	
	//we need minimum of two arguments (context and node type)
	if ( 2 > argLen) {
		console.error( "crochetNode::crochetNode - not enough arguments to create a node" );
    throw 'crochetNode 001';
	};
	
	argContext = arguments[0]; // will be used later to register the new node in its parent crochetStitch or its parent crochetProject
	argType = arguments[1]; // will be used to set the node's type and also control the creation of other properties
	
	// for each new crochetNode, the context must be set as either the containing crochetStitch or the containing crochetProject
	if ( !( argContext instanceof crochetProject ||  argContext instanceof crochetStitch) ) {
		console.error( 'crochetNode::crochetNode - cannot create a node without valid context. crochetStitch or crochetProject required!' );
    throw 'crochetNode 002';
	};
	
	// for each new node its type must be set as one valid types, either by using the type code or type number.
	if ( !( 'string' === typeof( argType ) ) ) {
		console.error( 'crochetNode::crochetNode - invalid node type. String required' );
    throw 'crochetNode 003';
	};
	if ( !( crochetNode.IS_VALID_TYPE_CODE( argType ) ) ) {
		console.error( 'crochetNode::crochetNode - invalid node type: "' + argType + '"' );
    throw 'crochetNode 004';
	};
	
	// here we validate if, given a specific number of arguments, each argument is of the correct type and value
	// and if they are valid we set some temporary variables
	switch ( argLen ) {
		case 2: // only context and nodeType
			createMode = "standalone";
			argX = 0;
			argY = 0;
			break;
		case 4: // crocehtNode( context, nodeType , x,  y )
			// cannot set the coordinates of a node to (x,y) if they are not numbers
			if ( 'number' != typeof( arguments[2] ) ||  'number' != typeof( arguments[3] ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, x, y ) - cannot set initial coordinates of a node to "' + arguments[2].constructor.name + '" and "' + arguments[3].constructor.name + '"!' );
        throw 'crochetNode 005';
			};
			createMode = "pinpoint";
			argX = arguments[2];
			argY = arguments[3];
			break;
		case 5: // crochetNode( context, type, fromNode, alongLink, linkType|link Length )
			// cannot extend an existing link if the start position (fromNode) is not a crochetNode
			if ( !( arguments[2] instanceof crochetNode ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, fromNode, alongLink, {linkType|linkLength} ) - cannot set initial coordinates as a shift from "' + arguments[2].constructor.name + '". crochetNode required' );
        throw 'crochetNode 006';
			};
			// cannot extend an existing link, if the direction (prevLink) is not a crochetLink
			if ( !( arguments[3] instanceof crochetLink ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, fromNode, alongLink, {linkType|linkLength} ) - cannot set initial coordinates as a shift in line with "' + arguments[3].constructor.name + '". crochetLink required' );
        throw 'crochetNode 007';
			};
			// cannot extend an existing link, if the extension type (linkType) is not a valid link type code, nor is the length (linkLength) a number
			if ( !( 'number' == typeof( arguments[4] ) || 'string' == typeof( arguments[4] ) ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, fromNode, alongLink, {linkType|linkLength} ) - cannot set initial coordinates as a shift by "' + arguments[4].constructor.name + '". Number or string required' );
        throw 'crochetNode 008';
			};
			if ( 'string' == arguments[4] && !( crocehtLink.IS_VALID_TYPE_CODE( arguments[4] ) ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, fromNode, alongLink, {linkType|linkLength} ) - cannot set initial coordinates with new link length specified as "' + arguments[4].constructor.name + '"' );
        throw 'crochetNode 009';
			};
			// finally: set all initiating variables
			createMode = "extension";
			argFromNode = arguments[2];
			argAlongLink = arguments[3];
      argLinkLength = arguments[4]
			if ( 'number' == typeof( arguments[4] ) ) {
				argLinkLength = arguments[4];
			} else {
        argLinkLength = arguments[4];
        argLinkLength = crochetLink.DEF_LENGTH_BY_TYPE( arguments[4] );
			};
			break;
		case 6: // crochetNode( context, nodeType, nodeArray, referenceLink, {linkType1|linkLength1}, {linkType2|linkLength2} )
			// to initiate position as a "counter weight" we need the nodeArray to be an array
			if ( !( arguments[2] instanceof Array ) ) {
				crochet.error( 'crochetNode::crochetNode( context, nodeType, nodeArray, prevLink, {linkType1|linkLength1}, {linkType2|linkLength2} ) - cannot set initial coordinates as a counter weight to "' + arguments[2].constructor.name + '". An array of crocehtNode is required' );
        throw 'crochetNode 010';
			};
			// to initiate the position as "counter weight", we need a reference axis, across which the counter-direction will be calculated
			if ( !( arguments[3] instanceof crochetLink ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, nodeArray, prevLink, {linkType1|linkLength1}, {linkType2|linkLength2} ) - cannot set initial coordinates in relation to "' + arguments[3].constructor.name + '". A crochetLink is required' );
        throw 'crochetNode 011';
			};
			// the new node shall be in specified distances from ends of the reference axis. these are specified explicitly (numbers) or as link type codes
			if ( !( 'number' == arguments[4] || 'string' == arguments[4] ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, nodeArray, prevLink, {linkType1|linkLength1}, {linkType2|linkLength2} ) - cannot set initial coordinates in relation to "' + arguments[4].constructor.name + '". Number or string required' );
        throw 'crochetNode 012';
			};
			if ( !( 'number' == arguments[5] || 'string' == arguments[5] ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, nodeArray, prevLink, {linkType1|linkLength1}, {linkType2|linkLength2} ) - cannot set initial coordinates in relation to "' + arguments[5].constructor.name + '". Number or string required' );
        throw 'crochetnode 013';
			};
			// if distances were specified as link type codes, they need to be valid types.
			if ( 'string' == arguments[4] && !crocehtLink.IS_VALID_TYPE_CODE( arguments[4] ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, nodeArray, prevLink, {linkType1|linkLength1}, {linkType2|linkLength2} ) - cannot set initial coordinates if link1 length is specified as "' + arguments[4] + '". Valid Link type code required' );
        throw 'crochetNode 014';
			};
			if ( 'string' == arguments[5] && !crocehtLink.IS_VALID_TYPE_CODE( arguments[5] ) ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, nodeArray, prevLink, {linkType1|linkLength1}, {linkType2|linkLength2} ) - cannot set initial coordinates if link2 length is specified as "' + arguments[5] + '". Valid Link type code required' );
        throw 'crochetnode 015';
			};
			// all elements of nodeArray must be nodes
			nodeArrayIsValid = true;
			nodesValidityFlags = arguments[2].map( function( e ) { return (e instanceof crochetNode); } );
			nodesValidityFlags.foreach( function( e ) { nodeArrayIsValid  = nodeArrayIsValid  && e; } );
			if ( !nodeArrayIsValid ) {
				console.error( 'crochetNode::crochetNode( context, nodeType, nodeArray, prevLink, {linkType1|linkLength1}, {linkType2|linkLength2} ) - cannot set initial coordinates as a counter weight. An array of all crochetNode elements is required' ); 
        throw 'crochetNode 016';
			};
			// finally: set all initiating variables
			createMode = 'split';
			argNodeArray = argument[2];
			argAcrossLink = arguments[3];
			if ( 'number' == arguments[4] ) {
				argFirstLinkLength = arguments[4];
			} else {
				argFirstLinkLength  = crochetLink.DEF_LENGTH_BY_TYPE( arguments[4] );
			};
			if ( 'number' == arguments[5] ) {
				argSecondLinkLength = arguments[5];
			} else {
				argSecondLinkLength  = crochetLink.DEF_LENGTH_BY_TYPE( arguments[5] );
			};	
		default:
			console.error( 'crochetNode::crochetNode - wrong number of arguments : ' + argLen );
      throw 'crochetNode 017';
			break;
	};
	
	// *********************
	// PRIVATE PROPERTIES
	// *********************
	
	// basic
	this._links = new Array();
	//this._neighbors = new Array();
	  
	// now we are ready to set the initial coordinates of the new node.
	switch( createMode ) {
		case 'standalone':
		case 'pinpoint':
			this.x = argX;
			this.y = argY;
			break;
		case 'extension':
			if ( argAlongLink.getSource() === argFromNode ) {
				p1 = argAlongLink.getTarget().getAsVector();
				p2 = argFromNode.getAsVector();
			} else if ( argAlongLink.getTarget() === argFromNode ) {
				p1 = argAlongLink.getSource().getAsVector();
        p2 = argFromNode.getAsVector();
			} else {
				console.error( 'crochetNode::CrochetNode( context, nodeType, fromNode, prevLink, {linkType|linkLength})- cannot create a node by extension, if fromNode is not one of the nodes connected by prevLink' );
        throw 'crochetNode 018';
			};
      //newXY = p2.getSumVector( p2.getSumVector( p1.scale( -1  ) ).setLen( 10 ) );
      newXY = p2.getSumVector( p2.getSumVector( p1.scale( -1 ) ).setLen( argLinkLength ) ).getArray();
			this.x = newXY[0];
			this.y = newXY[1];
      break;
		case "split":
			numOfNodes = argNodeArray.length;
			centerOfMass = new Vector( 0, 0 );
			argNodeArray.map( function( e ) { return new Vector( this.x, this.y ); } ).forEach( function( e ) { this.getSumVector( e ) }, centerOfMass);
			centerOfMass.scale ( 1 / numOfNodes );
			p1 = new Vector( argAcrossLink.getSource() );
			p2 = new Vector( argAcrossLink.getTarget() );
			
			break;
	};
	
	
	this._id = crochetNode.COUNTER.next();
	
	// *********************
	// PUBLIC METHODS
	// *********************
	
	this.getAsVector = function() {
		return new Vector( this.x, this.y );
	};
  
  this.registerLink = function ( link ) {
		if ( link instanceof crochetLink ) {
			this._links.push( link );
		}
	};
  
	
	/*
  function unRegisterLink( link ) {
		if ( link instanceof crochetLink ) {
			this._links.splice( this._links.indexOf( link ), 1 );
		}
		//TO DO: if this node is left with no links to it && it"s not an "ORIGIN" node - remove it from all contexts
	};
  */
	
	//////////////////////////////////////////
	//   THIS IS WHERE I LAST FINISHED !!!  //
	//////////////////////////////////////////
	
	this.getNeighbors = function( nodeType, linkType, linkDir ) {
		
	};
	
	this.remove = function () {
		// housekeeping
		/*
		delete all associated links
		unregister this node from all contexts
		*/
	}
	
	// functions for houskeeping the references form this node, to other parts of the crochet project
	/*
  this.registerNeighbor = function ( node ) {
		if ( node instanceof crochetNode ) {
			this._neighbors.push( node );
		}
		return this;
	}
  */
	
	/*
  this.unRegisterNeighbor = function ( node ) {
		if ( node instanceof crochetNode ) {
			this._neighbors.splice( this._neighbors.indexOf( node ), 1 );
		}
		return this;
	}
  */
};
