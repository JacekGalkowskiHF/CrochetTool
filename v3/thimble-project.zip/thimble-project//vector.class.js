function Vector() {
	
	argLen = arguments.length;
	
	//check if we have the right number of arguments to construct a vectorargLen = arguments.length;
	if ( argLen < 1 || argLen > 2 ) {
		console.error( 'Vector::Vector - not enough parameters to construct a Vector!' );
    throw 'Vector 001';
	};
	
	// set the vector, given the new coordinates as an array [newX, newY]
	this._setArray = function( arrayInput ) {
		// we need at least two arguments, each a number. Surplus coordinates will be ignored
		if ( ( 2 > arrayInput.length ) ) {
			console.error( 'Vector::Vector - cannot create a Vector from less than two (2) coordinates!' );
      throw 'Vector 002';
		};
		if (  !( 'number' === typeof( arrayInput[0] ) && 'number' == typeof( arrayInput[1] ) ) ) {
			console.error( 'Vector::Vector - cannot create a Vector from non-numerical coordinates!' );
      throw 'Vector 003';
		};
		this._x = arrayInput[0];
		this._y = arrayInput[1];
	};
	
	// 1 argument => construct the vector given an array of coordinates 
	// TO DO: or a node! or a link!
	if ( 1 == argLen ) {
		if ( !( arguments[0] instanceof Array ) ) {
			console.error( 'Vector::Vector - cannot create a Vector from "' + arguments.constructor.name + '"' );
      throw 'Vecotr 004';
		};
		this._setArray( arguments[0] );		
	};
	
	// 2 arguments => construct the vector using each coordinate separately
	if ( 2 == argLen ) {
		this._setArray( arguments );	
	};
	
	// return an array of coordinates of the vector
	this.getArray = function() {
		// a function that return the vector coordinates as a 2-element array
		arr = [
			this._x,
			this._y
		];
		return arr;
	};
	
	// return a new vector = sum of this and given
	this.getSumVector = function( v ) {
		if ( !( v instanceof Vector ) ) {
			console.error( 'Vector::moveByVector - cannot move a Vector by "' + v.constructor.name + '"' );
      throw 'Vector 005';
		} else {
			return new Vector( this._x + v._x, this._y + v._y );
		};
	};
	
	// move this vector by a delta, return this vector
	this.moveByVector = function( v ) {
		if ( !( v instanceof Vector ) ) {
			console.error( 'Vector::moveByVector - cannot move a Vector by "' + v.constructor.name + '"' );
      throw 'Vector 006';
		} else {
			return this._setArray( v.getArray() );
		};
	};
	
	// return the dot product of this and a given vector
	this.getDotProduct = function( v ) {
		if ( !( v instanceof Vector ) ) {
			console.error( 'Vector::dotProduct -  cannot move a Vector by "' + v.constructor.name + '"' );
      throw 'Vector 007';
		} else {
			return this._x * v._x + this._y * v._y;
		};
	};
	
	// return the cross product (length) of this and a given vector
	this.getCrossProductLen = function( v ) {
		if ( !( v instanceof Vector ) ) {
			console.error( 'Vector::dotProduct -  cannot perform a scalar multiplication of a Vector and a "' + v.constructor.name + '"' );
      throw 'Vector 008';
		} else {
			return this._x * v._y - this._y * v._x;			
		};
	};
	
	// return the length of this 
	this.getLen = function() {
			result = Math.sqrt( this._x * this._x + this._y * this._y );
			return result;
	};
	
	// scale this by a scalar, returns this	
	this.scale = function( s ) {
		if ( !( 'number' ===  typeof( s ) ) ) {
			console.error( 'Vector::scale -  cannot scale a Vector by "' + v.constructor.name + '"' );
      thrwo 'Vector 009';
		} else {
			this._x *= s;
			this._y *= s;
			return this;
		};
	}; 
	
	// return a new Vector: the unit base along the direction
	this.getBaseA = function( ){
		if ( this.getLen() == 0 ) {
			return new Vector( 0, 0 );
		} else {
			result = new Vector( this.getArray() );
			return result.scale( 1/this.getLen());
		}
	};
	
	// rotate this by an angle (argument is the angle, in radians), or by the angle of another vector (argument is a Vector)
	// returns this
	this.rotate = function( phi ) {
		if ( !( 'number' === typeof( phi ) ) && ! ( phi instanceof Vector ) ) {
			console.error( 'Vector::rotate - cannot rotate a Vector by "' + phi.constructor.name + '"');
      throw 'Vector 010';
		};
		if ( 'number' === typeof( phi ) ) {
			e1 = Math.cos( phi );
			e2 = Math.sin( phi );
		} else {
			e1 = phi.getBaseA()._x;
			e2 = phi.getBaseA()._y;
		};
		newX = e1 * this._x - e2 * this._y;
		newY = e2 * this._x + e1 * this._y;
		this._x = newX;
		this._y = newY;
		return this;
	};
	
	// return a new Vector: the unit base normal (anti-clockwise) to this
	this.getBaseL = function() {
		if ( this.getLen() == 0 ) {
			return this;
		} else {
			return this.getBaseA().rotate( new Vector( 0, 1 ) );
		}
	};
	
	// return a new Vector: the unit base normal (clockwise) to this
	this.getBaseR = function() {
		if ( this.getLen() == 0 ) {
			return this;
		} else {
			return this.getBaseA().rotate( new Vector( 0, -1 ) );
		}
	};
	
	// return a projection of a given Vector onto this
	this.getProjectionOf = function () {
		// 1st argument (required) - the vector to be projected
		// 2nd argument (optional)- bool: false (default)- project to tangent vector, true - project to normal vector
		if ( arguments.length < 1 ) {
			console.error( 'Vector::getProjectionOf - not enough arguments' );
      throw 'Vector 011';
		};
		v = arguments[0];
		// optionally set the direction from tangent to normal
		if ( arguments.length > 1 ) {
			baseNormal = true && arguments[1];
		} else {
			baseNormal = false
		};
		// is the input even a Vector itself? if so, then project to the desired base.
		if ( !( v instanceof Vector ) ) {
			console.error('Vector::getProjectionOf -  cannot project "' + v.constructor.name + '" onto a vector');
      throw 'Vector 012';
		} else {
			if ( !baseNormal ) {
				result = this.getBaseA().scale( this.getBaseA().getDotProduct( v ) );
			} else {
				result = this.getBaseL().scale( this.getBaseL().getDotProduct( v ) );
			};
			return result;
		};
	};
	
	// set this' length
	this.setLen = function( newLen ) {
		if ( 'number' != typeof( newLen ) ) {
			console.error( 'Vector::setLenght - cannot set length of a Vector to a non-numerical value!' );
      hrow 'Vector 013';
		} else {
			oldLen = this.getLen();
			if ( oldLen == 0 ) {
				this._x = newLen;
				this._y = 0;
			} else {
				this._x *= ( newLen / oldLen );
				this._y *= ( newLen / oldLen );
			};
			return this;
		};
	};
}